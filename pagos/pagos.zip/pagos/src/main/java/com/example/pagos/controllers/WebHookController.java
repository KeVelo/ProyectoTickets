package com.example.pagos.controllers;

import com.example.pagos.services.PagoService;
import com.stripe.model.Event;
import com.stripe.model.checkout.Session;
import com.stripe.net.Webhook;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/webhook")
public class WebHookController {

    private final PagoService pagoService;

    @Value("${stripe.webhook.secret}")
    private String endpointSecret;

    public WebHookController(PagoService pagoService) {
        this.pagoService = pagoService;
    }

    @PostMapping
    public ResponseEntity<String> handleWebhook(
            @RequestBody String payload,
            @RequestHeader("Stripe-Signature") String sigHeader) {
        try {
            // Verificar el evento de Stripe
            Event event = Webhook.constructEvent(payload, sigHeader, endpointSecret);

            // Procesar solo eventos relevantes
            if ("checkout.session.completed".equals(event.getType())) {
                Session session = (Session) event.getDataObjectDeserializer().getObject().orElse(null);
                if (session != null) {
                    pagoService.actualizarEstadoTransaccion(session.getId(), "SUCCESS");
                }
            } else if ("checkout.session.expired".equals(event.getType())) {
                Session session = (Session) event.getDataObjectDeserializer().getObject().orElse(null);
                if (session != null) {
                    pagoService.actualizarEstadoTransaccion(session.getId(), "FAILED");
                }
            }
            
            return ResponseEntity.ok("Evento recibido");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Error en la verificación del webhook");
        }
    }
}
