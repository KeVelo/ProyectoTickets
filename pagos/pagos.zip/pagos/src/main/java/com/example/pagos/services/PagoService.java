package com.example.pagos.services;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.example.pagos.models.Transaccion;
import com.example.pagos.repositories.TransaccionRepository;
import com.stripe.Stripe;
import com.stripe.model.checkout.Session;
import com.stripe.param.checkout.SessionCreateParams;

@Service
public class PagoService {

    private final TransaccionRepository transaccionRepository;

    @Value("${stripe.api.key}")
    private String stripeApiKey;

    public PagoService(TransaccionRepository transaccionRepository) {
        this.transaccionRepository = transaccionRepository;
    }

    public Session crearSesionStripe(Transaccion transaccion) throws Exception {
        // Configurar la clave de la API de Stripe
        Stripe.apiKey = stripeApiKey;
    
        // Crear los parámetros para la sesión de Stripe
        SessionCreateParams params = SessionCreateParams.builder()
                .setMode(SessionCreateParams.Mode.PAYMENT)
                .setSuccessUrl("http://localhost:4200/success") // Cambia según tu frontend
                .setCancelUrl("http://localhost:4200/cancel")
                .addLineItem(
                        SessionCreateParams.LineItem.builder()
                                .setQuantity(1L)
                                .setPriceData(
                                        SessionCreateParams.LineItem.PriceData.builder()
                                                .setCurrency("usd")
                                                .setUnitAmount((long) (transaccion.getMonto() * 100)) // En centavos
                                                .setProductData(
                                                        SessionCreateParams.LineItem.PriceData.ProductData.builder()
                                                                .setName(transaccion.getDescripcion() != null ? transaccion.getDescripcion() : "Producto sin nombre")
                                                                .build()
                                                )
                                                .build()
                                )
                                .build()
                )
                .build();
    
        // Crear la sesión en Stripe
        Session session = Session.create(params);
    
        // Guardar la transacción como PENDING
        transaccion.setEstado("PENDING");
        transaccion.setFechaCreacion(LocalDateTime.now());
        transaccion.setSessionId(session.getId());
        transaccionRepository.save(transaccion);
    
        return session;
    }
    
    
    public void actualizarEstadoTransaccion(String sessionId, String estado) {
        // Buscar la transacción por sessionId
        Transaccion transaccion = transaccionRepository.findBySessionId(sessionId);
    
        if (transaccion != null) {
            // Actualizar el estado
            transaccion.setEstado(estado);
            transaccionRepository.save(transaccion);
        } else {
            throw new RuntimeException("Transacción no encontrada para el sessionId: " + sessionId);
        }
    }
    
    

}
